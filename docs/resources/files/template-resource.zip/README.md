This is a placeholder file for the "Template Resource" example in the
Resources section. Replace this whole zip with your real files when you
copy this pattern for an actual resource.
